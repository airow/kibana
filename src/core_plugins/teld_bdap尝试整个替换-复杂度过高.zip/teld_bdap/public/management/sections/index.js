import 'plugins/teld_bdap/management/sections/settings';
import 'plugins/teld_bdap/management/sections/objects';
import 'plugins/teld_bdap/management/sections/indices';

import 'plugins/teld_bdap/discover/saved_searches/saved_searches';
import 'plugins/teld_bdap/discover/directives/no_results';
import 'plugins/teld_bdap/discover/directives/timechart';
import 'ui/collapsible_sidebar';
import 'plugins/teld_bdap/discover/components/field_chooser/field_chooser';
import 'plugins/teld_bdap/discover/controllers/discover';
import 'plugins/teld_bdap/discover/styles/main.less';
import 'ui/doc_table/components/table_row';
import savedObjectRegistry from 'ui/saved_objects/saved_object_registry';

// preload

savedObjectRegistry.register(require('plugins/teld_bdap/discover/saved_searches/saved_search_register'));

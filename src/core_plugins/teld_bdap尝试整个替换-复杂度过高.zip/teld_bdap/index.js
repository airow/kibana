import Promise from 'bluebird';
import { mkdirp as mkdirpNode } from 'mkdirp';
import manageUuid from './server/lib/manage_uuid';
//import ingest from './server/routes/api/ingest';
//import search from './server/routes/api/search';
//import settings from './server/routes/api/settings';
//import scripts from './server/routes/api/scripts';
//import * as systemApi from './server/lib/system_api';

const mkdirp = Promise.promisify(mkdirpNode);

module.exports = function (kibana) {
  const kbnBaseUrl = '/app/teld_bdap';
  const pluginBasePath  = 'plugins/teld_bdap';

  return new kibana.Plugin({
    //id: 'bdap', /* id 也要和文件夹一致，否则optimize时会提示找不到module */
    config: function (Joi) {
      return Joi.object({
        enabled: Joi.boolean().default(true),
        defaultAppId: Joi.string().default('discover'),
        index: Joi.string().default('.kibana')
      }).default();
    },

    uiExports: {
      // Register the app component of our plugin to uiExports
      app: {
        //id: 'teld_bdap',
        // The title of the app (will be shown to the user)
        title: 'Teld Kibana',
        // An description of the application.
        description: 'the kibana you know and love',
        // The require reference to the JavaScript file for this app
        main: `${pluginBasePath}/app`, /* 'plugins/teld_bdap/app' 目录下的public文件夹 */
        // The require reference to the icon of the app
        icon: `${pluginBasePath}/icon.svg`,

        listed: true,
        uses: [
          'visTypes',
          'spyModes',
          'fieldFormats',
          'navbarExtensions',
          'managementSections',
          'devTools',
          'docViews'
        ],

        /*
        injectVars: function (server, options) {
          let config = server.config();
          return {
            kbnDefaultAppId: config.get('kibana.defaultAppId'),
            tilemap: config.get('tilemap')
          };
        },*/
      },


      links: [
        {
          id: 'bdap:discover',
          title: 'Teld Discover',
          order: -1003,
          url: `${kbnBaseUrl}#/discover`,
          description: 'interactively explore your data',
          icon: `${pluginBasePath}/assets/discover.svg`,
        },
        {
          id: 'bdap:kibanadiscover',
          title: 'Teld To Kibana Discover',
          order: -1003,
          url: `/app/kibana/#/discover`,
          description: '链接到Kibana Discover',
          icon: 'plugins/teld_bdap/assets/discover.svg',
        },
        /*
        {
          id: 'kibana:discover',
          title: 'Discover',
          order: -1003,
          url: `${kbnBaseUrl}#/discover`,
          description: 'interactively explore your data',
          icon: 'plugins/teld_bdap/assets/discover.svg',
        }, {
          id: 'kibana:visualize',
          title: 'Visualize',
          order: -1002,
          url: `${kbnBaseUrl}#/visualize`,
          description: 'design data visualizations',
          icon: 'plugins/teld_bdap/assets/visualize.svg',
        }, {
          id: 'kibana:dashboard',
          title: 'Dashboard',
          order: -1001,
          url: `${kbnBaseUrl}#/dashboard`,
          description: 'compose visualizations for much win',
          icon: 'plugins/teld_bdap/assets/dashboard.svg',
        }, {
          title: 'Dev Tools',
          order: 9001,
          url: '/app/kibana#/dev_tools',
          description: 'development tools',
          icon: 'plugins/teld_bdap/assets/wrench.svg'
        }, {
          id: 'kibana:management',
          title: 'Management',
          order: 9003,
          url: `${kbnBaseUrl}#/management`,
          description: 'define index patterns, change config, and more',
          icon: 'plugins/teld_bdap/assets/settings.svg',
          linkToLastSubUrl: false
        },*/
      ],

      injectDefaultVars(server, options) {
        return {
          kbnIndex: options.index,
          kbnBaseUrl
        };
      },
    },

    /*
    preInit: async function (server) {
      try {
        // Create the data directory (recursively, if the a parent dir doesn't exist).
        // If it already exists, does nothing.
        await mkdirp(server.config().get('path.data'));
      } catch (err) {
        server.log(['error', 'init'], err);
        // Stop the server startup with a fatal error
        throw err;
      }
    },
    */
    init: function (server, options) {
      // uuid
      manageUuid(server);
      // routes
      // ingest(server);
      // search(server);
      // settings(server);
      // scripts(server);

      //server.expose('systemApi', systemApi);
    }
  });
};

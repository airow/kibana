### index.js 
```
为插件的入口文件
```

### package.json
 ```
 文件中的name属相为文件夹的名称，这是为了避免不必要的麻烦   
   The name from the package.json must be equal to the name of the folder your plugin lies in
   ref: https://www.timroes.de/2015/12/02/writing-kibana-4-plugins-basics/ [Plugin Basics]
   name 等于插件文件夹的名称，强烈建议
 ```

### public文件夹
```
在这个文件夹中的文件是client browser中执行的代码
Besides those two files most plugins will have a folder named public in their root directory. All files that won't run server-side but will be transferred to the client browser go inside this folder.
```

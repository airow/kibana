import { registerLanguages } from './register_languages';

export default function (server) {
  registerLanguages(server);
}

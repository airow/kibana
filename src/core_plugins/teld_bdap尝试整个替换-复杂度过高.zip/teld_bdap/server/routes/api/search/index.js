import registerCount from './count/register_count';

export default function (server) {
  registerCount(server);
}
